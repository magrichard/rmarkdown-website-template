#######
#######
Here you can find the datasets associated with the publication:
PenDA, a rank-based method for Personalized Differential Analysis: application to lung cancer
contact: magali.richard@univ-grenoble-alpes.fr 
#######
#######

## TCGA datasets ##
Two datasets of gene expression (HTSeq-Counts) were downloaded from The Cancer Genome Atlas program (https://portal.gdc.cancer.gov/). The datasets contain tumor (’01’ barcoded samples) and control (‘11’ barcoded samples) tissues from two non-small cells lung cancers: lung adenocarcinoma (LUAD or ADC) and lung squamous cell (LUSC or SQCC). Patients with prior malignancies and replicated samples were removed from the analysis. We kept 1026 samples: 
tcga_data_case.rds => 455 ADC tumors, 473 SQCC tumors 
tcga_data_ctrl.rds => 98 control tissues consisting of normal adjacent lung tissue samples (50 from the ADC cohort, 48 from the SQCC cohort)
tcga_exp_grp.rds => clinical metadata (experimental grouping for all samples)
For further analysis, we selected 19177 protein coding genes (hg38 reference genome). This corresponds to protein-coding genes of the base RefSeqGene (https://www.ncbi.nlm.nih.gov/refseq/rsg/). We then normalized the HTSeq-Counts using the estimateSizeFactors and the count functions of the DESeq2 package. Finally, data were filtered to remove genes with null expression (counts = 0) in all samples (controls and tumors). At the end, we kept 18143 protein-coding genes.

## Grenoble Hospital cohort ##
Data are coming from the GSE30219 study (Affymetrix Human Genome U133 Plus 2.0 Array). 
grenoble_data_case.rds => 293 lung tumors
grenoble_data_ctrl.rds => 14 control samples.
grenoble_exp_grp.rds => clinical metadata (experimental grouping for all samples)
Samples are normalised together from .CEL files [GSE30219] using affy::justRMA method.Association between probeset and gene was done using platform annotation [GPL570]. For genes owning more than one probeset, we only keep the probeset that have the largest IQR over tumoral samples.
[GSE30219] https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE30219
[GPL570] https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GPL570



